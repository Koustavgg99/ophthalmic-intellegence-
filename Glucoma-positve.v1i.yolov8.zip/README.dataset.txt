# Glucoma-positve > 2024-06-17 7:15pm
https://universe.roboflow.com/indrajit-bmfjc/glucoma-positve

Provided by a Roboflow user
License: CC BY 4.0

