# Glucoma_positve > 2024-06-17 5:00pm
https://universe.roboflow.com/indrajit-bmfjc/glucoma_positve

Provided by a Roboflow user
License: CC BY 4.0

